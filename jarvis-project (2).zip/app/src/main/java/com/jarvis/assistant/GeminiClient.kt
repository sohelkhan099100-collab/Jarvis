package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to Google's Gemini API (free tier via the user's own AI Studio key).
 * No extra libraries needed. Call from a background thread only.
 *
 * Strategy:
 *  1. Try the chosen model, then a few known fallback models.
 *  2. A temporary server error (500/503) is retried once after a short wait.
 *  3. If everything fails, ask Google which models this key can really use
 *     and try a few of those.
 *  4. If it still fails, the error message lists exactly what each model said.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-2.5-flash"
    private val FALLBACKS = listOf("gemini-2.5-flash-lite", "gemini-3.6-flash")
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    data class Turn(val role: String, val text: String) // role = "user" or "model"

    sealed class Result {
        data class Ok(val text: String, val model: String) : Result()
        data class Err(val message: String) : Result()
    }

    private sealed class Attempt {
        data class Success(val text: String) : Attempt()
        data class Retry(val message: String, val transient: Boolean = false) : Attempt()
        data class Fatal(val message: String) : Attempt()
    }

    fun ask(apiKey: String, preferredModel: String, turns: List<Turn>, systemPrompt: String): Result {
        val tried = LinkedHashSet<String>()
        val errors = mutableListOf<String>()

        val first = LinkedHashSet<String>()
        if (preferredModel.isNotBlank()) first.add(preferredModel)
        first.addAll(FALLBACKS)

        for (m in first) {
            tried.add(m)
            when (val r = attempt(apiKey, m, turns, systemPrompt)) {
                is Attempt.Success -> return Result.Ok(r.text, m)
                is Attempt.Fatal -> return Result.Err(r.message)
                is Attempt.Retry -> errors.add("$m → ${r.message}")
            }
        }

        // Ask Google which models this key can use, and try a few of them.
        val discovered = listModels(apiKey).filter { it !in tried }.take(4)
        for (m in discovered) {
            tried.add(m)
            when (val r = attempt(apiKey, m, turns, systemPrompt)) {
                is Attempt.Success -> return Result.Ok(r.text, m)
                is Attempt.Fatal -> return Result.Err(r.message)
                is Attempt.Retry -> errors.add("$m → ${r.message}")
            }
        }

        return Result.Err(
            "कोई भी मॉडल जवाब नहीं दे पाया। हर मॉडल का नतीजा:\n" + errors.joinToString("\n")
        )
    }

    /** One try, plus one more try after 1.5 seconds if Google says "busy". */
    private fun attempt(apiKey: String, model: String, turns: List<Turn>, system: String): Attempt {
        val r = callOnce(apiKey, model, turns, system)
        if (r is Attempt.Retry && r.transient) {
            try {
                Thread.sleep(1500)
            } catch (e: InterruptedException) {
                return r
            }
            return callOnce(apiKey, model, turns, system)
        }
        return r
    }

    /** Returns model names (without the "models/" prefix) that can generate text. */
    private fun listModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("$BASE/models?pageSize=100").openConnection() as HttpURLConnection
            conn.requestMethod = "GET"
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.setRequestProperty("x-goog-api-key", apiKey)
            if (conn.responseCode !in 200..299) return emptyList()
            val text = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = JSONObject(text).optJSONArray("models") ?: return emptyList()
            val bad = listOf("image", "tts", "live", "audio", "embed", "robotics", "computer", "native", "vision")
            val names = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val name = o.optString("name").removePrefix("models/")
                val methods = o.optJSONArray("supportedGenerationMethods")
                var canGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") canGenerate = true
                    }
                }
                if (canGenerate && name.contains("flash") && bad.none { name.contains(it) }) {
                    names.add(name)
                }
            }
            // stable models first, preview/experimental last
            names.sortedBy { if (it.contains("preview") || it.contains("exp")) 1 else 0 }
        } catch (e: Exception) {
            emptyList()
        } finally {
            conn?.disconnect()
        }
    }

    private fun callOnce(
        apiKey: String,
        model: String,
        turns: List<Turn>,
        systemPrompt: String
    ): Attempt {
        var conn: HttpURLConnection? = null
        try {
            val body = JSONObject()
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
            val contents = JSONArray()
            for (t in turns) {
                contents.put(
                    JSONObject()
                        .put("role", t.role)
                        .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
                )
            }
            body.put("contents", contents)
            body.put(
                "generationConfig",
                JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048)
            )

            val url = URL("$BASE/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code in 200..299) {
                return parseSuccess(text, model)
            }

            var apiMessage = ""
            try {
                apiMessage = JSONObject(text).optJSONObject("error")?.optString("message") ?: ""
            } catch (e: Exception) {
                // ignore: keep empty message
            }
            apiMessage = apiMessage.take(160)

            return when (code) {
                400 ->
                    if (apiMessage.contains("API key", ignoreCase = true))
                        Attempt.Fatal("API key सही नहीं है। ⚙ सेटिंग्स में दोबारा कॉपी-पेस्ट करें।")
                    else Attempt.Retry("400: $apiMessage")
                401, 403 ->
                    Attempt.Fatal("API key काम नहीं कर रही या अनुमति नहीं है ($code)। $apiMessage")
                404 -> Attempt.Retry("404 मॉडल नहीं मिला")
                429 -> Attempt.Retry("429 फ़्री लिमिट पूरी: $apiMessage")
                500, 502, 503, 504 -> Attempt.Retry("$code सर्वर व्यस्त: $apiMessage", transient = true)
                else -> Attempt.Retry("$code: $apiMessage")
            }
        } catch (e: IOException) {
            return Attempt.Fatal("इंटरनेट कनेक्शन की समस्या: ${e.message ?: "अज्ञात"}")
        } catch (e: Exception) {
            return Attempt.Fatal("अप्रत्याशित त्रुटि: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseSuccess(text: String, model: String): Attempt {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return Attempt.Fatal(
                if (reason.isNotEmpty()) "Google ने यह अनुरोध रोक दिया ($reason)।"
                else "कोई जवाब नहीं मिला।"
            )
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
        }
        val out = sb.toString().trim()
        return if (out.isEmpty()) Attempt.Retry("खाली जवाब मिला") else Attempt.Success(out)
    }
}
