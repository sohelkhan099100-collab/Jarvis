package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {

    companion object {
        private const val USER = 0
        private const val JARVIS = 1
        private const val ERR = 2
        private const val SYSTEM_PROMPT =
            "तुम J.A.R.V.I.S. हो, यूज़र के फ़ोन का पर्सनल AI असिस्टेंट (Iron Man के JARVIS की तरह). " +
                "यूज़र जिस भाषा में बोले उसी में जवाब दो: हिंदी (देवनागरी में) या English. " +
                "जवाब छोटे रखो (1 से 3 वाक्य), साफ़ और मददगार. " +
                "Markdown, bullets और emoji मत इस्तेमाल करो, क्योंकि जवाब बोलकर सुनाया जाएगा."
    }

    private lateinit var prefs: SharedPreferences
    private lateinit var core: CoreView
    private lateinit var wave: WaveView
    private lateinit var statusView: TextView
    private lateinit var batteryView: TextView
    private lateinit var chat: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText

    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private val history = ArrayList<Pair<String, String>>()
    private var busy = false

    private val cyan = Color.parseColor("#00E5FF")
    private val blue = Color.parseColor("#2979FF")

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
            if (level >= 0 && scale > 0) {
                batteryView.text = "🔋 " + (level * 100 / scale) + "%"
            }
        }
    }

    private fun dp(x: Int): Int = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        prefs = getSharedPreferences("jarvis", MODE_PRIVATE)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.BLACK)
        root.setPadding(dp(16), dp(12), dp(16), dp(8))

        // top bar
        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(this)
        title.text = "J.A.R.V.I.S"
        title.setTextColor(cyan)
        title.textSize = 22f
        title.letterSpacing = 0.2f
        title.setTypeface(title.typeface, android.graphics.Typeface.BOLD)
        top.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        batteryView = TextView(this)
        batteryView.setTextColor(Color.WHITE)
        batteryView.textSize = 14f
        top.addView(batteryView)
        val online = TextView(this)
        online.text = "  ● ONLINE v3"
        online.setTextColor(cyan)
        online.textSize = 14f
        top.addView(online)
        root.addView(top)

        // core
        core = CoreView(this)
        root.addView(core, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(240)))

        statusView = TextView(this)
        statusView.gravity = Gravity.CENTER
        statusView.setTextColor(Color.parseColor("#8A99A6"))
        statusView.textSize = 16f
        root.addView(statusView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        wave = WaveView(this)
        val wlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(22))
        wlp.setMargins(0, dp(6), 0, dp(6))
        root.addView(wave, wlp)

        // chat
        scroll = ScrollView(this)
        chat = LinearLayout(this)
        chat.orientation = LinearLayout.VERTICAL
        scroll.addView(chat, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // input row
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input = EditText(this)
        input.hint = "या यहाँ टाइप करें…"
        input.setHintTextColor(Color.parseColor("#667788"))
        input.setTextColor(Color.WHITE)
        input.textSize = 16f
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.maxLines = 3
        input.setPadding(dp(14), dp(10), dp(14), dp(10))
        val ibg = GradientDrawable()
        ibg.cornerRadius = dp(8).toFloat()
        ibg.setColor(Color.BLACK)
        ibg.setStroke(dp(2), cyan)
        input.background = ibg
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val sendBtn = roundButton("➤", 52, cyan, 22f)
        sendBtn.setOnClickListener {
            val t = input.text.toString()
            input.setText("")
            send(t)
        }
        row.addView(sendBtn)
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.setMargins(0, dp(8), 0, dp(8))
        root.addView(row, rlp)

        // bottom buttons
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        val settingsBtn = roundButton("⚙", 56, blue, 24f)
        settingsBtn.setOnClickListener { showSettings() }
        val micBtn = roundButton("🎙", 76, cyan, 32f)
        micBtn.setOnClickListener { startListening() }
        val clearBtn = roundButton("🗑", 56, blue, 22f)
        clearBtn.setOnClickListener { clearChat() }
        bottom.addView(settingsBtn)
        bottom.addView(micBtn)
        bottom.addView(clearBtn)
        root.addView(bottom)

        setContentView(root)

        tts = TextToSpeech(this, this)
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        setState("तैयार — माइक दबाइए", CoreView.IDLE)
        greet()
    }

    override fun onDestroy() {
        try { unregisterReceiver(batteryReceiver) } catch (e: Exception) { }
        recognizer?.destroy()
        tts?.shutdown()
        super.onDestroy()
    }

    // ---------- UI helpers ----------

    private fun roundButton(label: String, sizeDp: Int, color: Int, textSp: Float): TextView {
        val tv = TextView(this)
        tv.text = label
        tv.textSize = textSp
        tv.gravity = Gravity.CENTER
        tv.setTextColor(color)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#06151C"))
        bg.setStroke(dp(2), color)
        tv.background = bg
        val lp = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp))
        lp.setMargins(dp(12), 0, dp(12), 0)
        tv.layoutParams = lp
        return tv
    }

    private fun addBubble(text: String, kind: Int) {
        val tv = TextView(this)
        tv.text = text
        tv.textSize = 16f
        tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.setTextIsSelectable(true)
        val bg = GradientDrawable()
        bg.cornerRadius = dp(18).toFloat()
        when (kind) {
            USER -> {
                bg.setColor(Color.parseColor("#050B1F"))
                bg.setStroke(dp(1), Color.parseColor("#2A4FD6"))
            }
            ERR -> {
                bg.setColor(Color.parseColor("#1E0809"))
                bg.setStroke(dp(1), Color.parseColor("#B3263A"))
            }
            else -> {
                bg.setColor(Color.parseColor("#021518"))
                bg.setStroke(dp(1), Color.parseColor("#167A8C"))
            }
        }
        tv.background = bg
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.82).toInt()
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, dp(6), 0, dp(6))
        lp.gravity = if (kind == USER) Gravity.END else Gravity.START
        tv.layoutParams = lp
        chat.addView(tv)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun setState(label: String, mode: Int) {
        statusView.text = label
        core.mode = mode
        wave.active = (mode == CoreView.LISTEN || mode == CoreView.SPEAK)
    }

    private fun greet() {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when {
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        addBubble("$g. JARVIS is online. बताइए, आज मैं आपकी क्या सहायता कर सकता हूँ?", JARVIS)
    }

    private fun clearChat() {
        tts?.stop()
        history.clear()
        chat.removeAllViews()
        setState("तैयार — माइक दबाइए", CoreView.IDLE)
        greet()
    }

    private fun showSettings() {
        val box = EditText(this)
        box.hint = "Gemini API key यहाँ paste करें"
        box.setText(prefs.getString("key", "") ?: "")
        box.setSingleLine(true)
        val pad = dp(16)
        val wrap = LinearLayout(this)
        wrap.setPadding(pad, pad, pad, 0)
        wrap.addView(box, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        AlertDialog.Builder(this)
            .setTitle("सेटिंग्स")
            .setView(wrap)
            .setPositiveButton("सेव") { _, _ ->
                prefs.edit().putString("key", box.text.toString().trim()).apply()
                addBubble("API key सेव हो गई।", JARVIS)
            }
            .setNegativeButton("रद्द", null)
            .show()
    }

    // ---------- chat ----------

    private fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || busy) return
        addBubble(t, USER)
        val key = (prefs.getString("key", "") ?: "").trim()
        if (key.isEmpty()) {
            addBubble("पहले ⚙ दबाकर अपनी Gemini API key डालिए।", ERR)
            return
        }
        busy = true
        tts?.stop()
        history.add(Pair("user", t))
        setState("सोच रहा हूँ…", CoreView.THINK)
        val snapshot = ArrayList(history.takeLast(14))
        Thread {
            val r = Gemini.chat(key, snapshot, SYSTEM_PROMPT)
            runOnUiThread {
                busy = false
                val reply = r.text
                if (reply != null) {
                    history.add(Pair("model", reply))
                    addBubble(reply, JARVIS)
                    speak(reply)
                } else {
                    if (history.isNotEmpty()) history.removeAt(history.size - 1)
                    addBubble(r.error ?: "कुछ गड़बड़ हो गई।", ERR)
                    setState("तैयार — माइक दबाइए", CoreView.IDLE)
                }
            }
        }.start()
    }

    // ---------- voice out ----------

    override fun onInit(status: Int) {
        if (status != TextToSpeech.SUCCESS) return
        val r = tts?.setLanguage(Locale("hi", "IN"))
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts?.setLanguage(Locale.US)
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                runOnUiThread { setState("बोल रहा हूँ…", CoreView.SPEAK) }
            }

            override fun onDone(utteranceId: String?) {
                runOnUiThread { setState("तैयार — माइक दबाइए", CoreView.IDLE) }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                runOnUiThread { setState("तैयार — माइक दबाइए", CoreView.IDLE) }
            }
        })
    }

    private fun speak(text: String) {
        val clean = text.replace("*", "").replace("#", "").replace("`", "")
        val engine = tts
        if (engine == null) {
            setState("तैयार — माइक दबाइए", CoreView.IDLE)
            return
        }
        engine.speak(clean, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    // ---------- voice in ----------

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            setState("तैयार — माइक दबाइए", CoreView.IDLE)
            if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                addBubble("सुनाई नहीं दिया, फिर से बोलिए।", ERR)
            } else {
                addBubble("माइक में समस्या (code $error)।", ERR)
            }
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val said = list?.firstOrNull()
            if (said.isNullOrBlank()) {
                setState("तैयार — माइक दबाइए", CoreView.IDLE)
            } else {
                send(said)
            }
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            addBubble("इस फ़ोन पर voice recognition उपलब्ध नहीं है। टाइप करके बात कीजिए।", ERR)
            return
        }
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(listener)
        }
        tts?.stop()
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        setState("सुन रहा हूँ…", CoreView.LISTEN)
        recognizer?.startListening(i)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListening()
        } else if (requestCode == 1) {
            addBubble("माइक की अनुमति नहीं मिली। टाइप करके बात कीजिए।", ERR)
        }
    }
}
