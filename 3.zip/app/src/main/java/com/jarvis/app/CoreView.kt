package com.jarvis.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

class CoreView(context: Context) : View(context) {
    companion object {
        const val IDLE = 0
        const val LISTEN = 1
        const val THINK = 2
        const val SPEAK = 3
    }

    var mode: Int = IDLE

    private var t = 0f
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG)
    private val orb = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val arcRect = RectF()
    private val cyan = Color.parseColor("#00E5FF")
    private val blue = Color.parseColor("#2979FF")

    private val anim = ValueAnimator.ofFloat(0f, 360f).apply {
        duration = 9000
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val r = min(w, h) / 2f
        glow.shader = RadialGradient(
            w / 2f, h / 2f, r,
            intArrayOf(Color.parseColor("#6600B0FF"), Color.parseColor("#2200B0FF"), Color.TRANSPARENT),
            floatArrayOf(0.3f, 0.7f, 1f),
            Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val speed = when (mode) {
            LISTEN -> 2
            THINK -> 4
            SPEAK -> 3
            else -> 1
        }
        val a = t * speed
        val pulse = if (mode == IDLE) 1f else 1f + 0.07f * sin(Math.toRadians((a * 2f).toDouble())).toFloat()

        canvas.drawCircle(cx, cy, r, glow)

        // tick marks
        stroke.pathEffect = null
        stroke.color = Color.parseColor("#00B8D4")
        stroke.strokeWidth = 3f
        canvas.save()
        canvas.rotate(a / 2f, cx, cy)
        for (i in 0 until 60) {
            canvas.save()
            canvas.rotate(i * 6f, cx, cy)
            val len = if (i % 5 == 0) r * 0.10f else r * 0.05f
            canvas.drawLine(cx, cy - r * 0.92f, cx, cy - r * 0.92f + len, stroke)
            canvas.restore()
        }
        canvas.restore()

        // dashed ring
        stroke.color = blue
        stroke.strokeWidth = 3f
        stroke.pathEffect = DashPathEffect(floatArrayOf(14f, 14f), 0f)
        canvas.save()
        canvas.rotate(-a, cx, cy)
        canvas.drawCircle(cx, cy, r * 0.78f, stroke)
        canvas.restore()
        stroke.pathEffect = null

        // thin inner ring
        stroke.color = Color.parseColor("#1A6F8F")
        stroke.strokeWidth = 3f
        canvas.drawCircle(cx, cy, r * 0.56f, stroke)

        // bold rotating arcs
        stroke.color = cyan
        stroke.strokeWidth = 10f
        arcRect.set(cx - r * 0.65f, cy - r * 0.65f, cx + r * 0.65f, cy + r * 0.65f)
        canvas.save()
        canvas.rotate(a, cx, cy)
        canvas.drawArc(arcRect, 200f, 90f, false, stroke)
        canvas.drawArc(arcRect, 20f, 90f, false, stroke)
        canvas.restore()

        // orb
        val orbR = r * 0.32f * pulse
        orb.shader = RadialGradient(
            cx, cy, orbR,
            intArrayOf(Color.WHITE, cyan, blue),
            floatArrayOf(0f, 0.4f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, orbR, orb)
    }
}

class WaveView(context: Context) : View(context) {
    var active: Boolean = false

    private var t = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#00B8D4") }
    private val anim = ValueAnimator.ofFloat(0f, (2 * Math.PI).toFloat()).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener {
            t = it.animatedValue as Float
            invalidate()
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        anim.start()
    }

    override fun onDetachedFromWindow() {
        anim.cancel()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val n = 40
        val gap = width / n.toFloat()
        val cy = height / 2f
        val dp = resources.displayMetrics.density
        for (i in 0 until n) {
            val extra = if (active) 3f * abs(sin(t * 2 + i * 0.7f)) else 0.6f * sin(t + i * 0.5f) + 0.6f
            canvas.drawCircle(gap * (i + 0.5f), cy, dp * (2.5f + extra), p)
        }
    }
}
