package com.jarvis.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class GeminiResult(val text: String?, val error: String?)

object Gemini {
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta"

    // Used only if Google's model list cannot be fetched.
    private val FALLBACK = listOf(
        "gemini-2.5-flash-lite",
        "gemini-2.5-flash",
        "gemini-flash-lite-latest",
        "gemini-flash-latest"
    )

    private var cachedModels: List<String>? = null
    private var lastGood: String? = null

    private fun http(method: String, url: String, key: String, body: String?, readMs: Int): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = 15000
            c.readTimeout = readMs
            c.setRequestProperty("x-goog-api-key", key)
            if (body != null) {
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        } finally {
            c.disconnect()
        }
    }

    private fun version(name: String): Double {
        val m = Regex("gemini-(\\d+(?:\\.\\d+)?)").find(name) ?: return 0.0
        return m.groupValues[1].toDoubleOrNull() ?: 0.0
    }

    private fun isKeyProblem(code: Int, resp: String): Boolean {
        if (code == 401) return true
        if (code == 400 && (resp.contains("API key not valid") || resp.contains("API_KEY_INVALID"))) return true
        if (code == 403 && (resp.contains("API key") || resp.contains("PERMISSION_DENIED"))) return true
        return false
    }

    /** Returns the list of models to try, or null (and sets keyBad) if the key is rejected. */
    private fun modelList(key: String): List<String>? {
        cachedModels?.let { return it }
        val result = ArrayList<String>()
        try {
            val (code, body) = http("GET", "$BASE/models?pageSize=200", key, null, 15000)
            if (isKeyProblem(code, body)) return null
            if (code == 200) {
                val arr = JSONObject(body).optJSONArray("models") ?: JSONArray()
                val bad = listOf(
                    "image", "tts", "audio", "live", "embed", "vision", "robotics", "computer",
                    "thinking", "exp", "gemma", "learnlm", "aqa", "imagen", "veo", "deep"
                )
                val found = ArrayList<String>()
                for (i in 0 until arr.length()) {
                    val m = arr.getJSONObject(i)
                    val name = m.optString("name").removePrefix("models/")
                    val methods = m.optJSONArray("supportedGenerationMethods")
                    var ok = false
                    if (methods != null) {
                        for (j in 0 until methods.length()) {
                            if (methods.getString(j) == "generateContent") ok = true
                        }
                    }
                    if (ok && name.startsWith("gemini") && name.contains("flash") && bad.none { name.contains(it) }) {
                        found.add(name)
                    }
                }
                val sorted = found.distinct().sortedWith(
                    compareBy<String>({ if (it.contains("lite")) 0 else 1 }, { -version(it) })
                )
                result.addAll(sorted.take(8))
            }
        } catch (e: Exception) {
            // ignore, fall back to the built-in list
        }
        for (f in FALLBACK) if (!result.contains(f)) result.add(f)
        cachedModels = result
        return result
    }

    private fun buildBody(history: List<Pair<String, String>>, system: String): String {
        val root = JSONObject()
        root.put(
            "systemInstruction",
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system)))
        )
        val contents = JSONArray()
        var started = false
        for ((role, text) in history) {
            if (!started && role != "user") continue
            started = true
            contents.put(
                JSONObject().put("role", role)
                    .put("parts", JSONArray().put(JSONObject().put("text", text)))
            )
        }
        root.put("contents", contents)
        root.put("generationConfig", JSONObject().put("maxOutputTokens", 2048).put("temperature", 0.7))
        return root.toString()
    }

    private fun parseText(resp: String): String {
        return try {
            val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts")
            val sb = StringBuilder()
            for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            sb.toString().trim()
        } catch (e: Exception) {
            ""
        }
    }

    fun chat(key: String, history: List<Pair<String, String>>, system: String): GeminiResult {
        val keyMsg = "API key सही नहीं लगती। ⚙ दबाकर key दोबारा डालिए।"
        val models = modelList(key) ?: return GeminiResult(null, keyMsg)
        val order = ArrayList<String>()
        lastGood?.let { if (models.contains(it)) order.add(it) }
        for (m in models) if (!order.contains(m)) order.add(m)

        val body = buildBody(history, system)
        val deadline = System.currentTimeMillis() + 80000
        var log = StringBuilder()

        for (round in 0 until 2) {
            log = StringBuilder()
            for (m in order) {
                if (System.currentTimeMillis() > deadline) break
                try {
                    val (code, resp) = http("POST", "$BASE/models/$m:generateContent", key, body, 20000)
                    if (code == 200) {
                        val text = parseText(resp)
                        if (text.isNotEmpty()) {
                            lastGood = m
                            return GeminiResult(text, null)
                        }
                        log.append(m).append(": खाली जवाब\n")
                    } else {
                        if (isKeyProblem(code, resp)) return GeminiResult(null, keyMsg)
                        log.append(m).append(": ").append(code).append("\n")
                    }
                } catch (e: Exception) {
                    log.append(m).append(": ").append(e.javaClass.simpleName).append("\n")
                }
            }
            if (round == 0 && System.currentTimeMillis() < deadline) {
                try { Thread.sleep(2500) } catch (e: InterruptedException) { }
            }
        }
        cachedModels = null // refresh the model list next time
        return GeminiResult(null, "सभी Google models अभी busy हैं। थोड़ी देर बाद फिर कोशिश करें।\n\n" + log.toString().trim())
    }
}
