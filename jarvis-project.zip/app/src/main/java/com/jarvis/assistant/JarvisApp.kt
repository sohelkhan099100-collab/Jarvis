package com.jarvis.assistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.BatteryManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldColors
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun JarvisApp(vm: MainViewModel) {
    val ctx = LocalContext.current
    var showSettings by remember { mutableStateOf(false) }
    var typed by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    val micLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.onMicPressed()
        else vm.showNotice("माइक की अनुमति के बिना मैं आपकी आवाज़ नहीं सुन सकता। आप टाइप करके भी बात कर सकते हैं।")
    }

    fun onMic() {
        val granted = ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) vm.onMicPressed() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(JColors.Black)
            .systemBarsPadding()
            .imePadding()
            .padding(horizontal = 16.dp)
    ) {
        StatusRow(vm.state) { vm.stopAll() }

        // Big animated AI core (tap = microphone)
        Box(
            Modifier
                .fillMaxWidth()
                .height(220.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onMic() },
            contentAlignment = Alignment.Center
        ) {
            JarvisCore(vm.state, vm.level, Modifier.fillMaxSize())
        }

        Text(
            text = stateLabel(vm.state),
            color = if (vm.state == JarvisState.LISTENING) JColors.Cyan else JColors.Dim,
            fontSize = 14.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
        if (vm.partial.isNotEmpty()) {
            Text(
                text = vm.partial,
                color = JColors.Text,
                fontSize = 15.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp)
            )
        }

        Waveform(
            state = vm.state,
            level = vm.level,
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .padding(vertical = 4.dp)
        )

        if (!vm.hasKey) {
            Banner("AI जवाब के लिए पहले ⚙ दबाकर Gemini API key डालिए।", JColors.Blue, null)
        }
        vm.notice?.let { Banner(it, JColors.Cyan) { vm.dismissNotice() } }

        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(vm.messages, key = { it.id }) { m -> ChatBubble(m) }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("या यहाँ टाइप करें…", color = JColors.Dim) },
                colors = fieldColors()
            )
            Spacer(Modifier.width(8.dp))
            RoundButton("➤", 48.dp, JColors.Cyan, 20) {
                if (typed.isNotBlank()) {
                    vm.sendTyped(typed.trim())
                    typed = ""
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundButton("⚙", 52.dp, JColors.Blue, 22) { showSettings = true }
            RoundButton(
                label = when (vm.state) {
                    JarvisState.LISTENING -> "■"
                    JarvisState.THINKING -> "…"
                    else -> "🎙"
                },
                size = 76.dp,
                color = if (vm.state == JarvisState.LISTENING) JColors.Red else JColors.Cyan,
                fontSize = 30
            ) { onMic() }
            RoundButton("🗑", 52.dp, JColors.Blue, 20) { vm.clearHistory() }
        }
    }

    if (showSettings) SettingsDialog(vm) { showSettings = false }
}

private fun stateLabel(s: JarvisState): String = when (s) {
    JarvisState.IDLE -> "तैयार — माइक दबाइए"
    JarvisState.LISTENING -> "सुन रहा हूँ…"
    JarvisState.THINKING -> "सोच रहा हूँ…"
    JarvisState.SPEAKING -> "बोल रहा हूँ… (टोकने के लिए माइक दबाइए)"
}

@Composable
fun fieldColors(): TextFieldColors = OutlinedTextFieldDefaults.colors(
    focusedTextColor = JColors.Text,
    unfocusedTextColor = JColors.Text,
    focusedBorderColor = JColors.Cyan,
    unfocusedBorderColor = JColors.Blue.copy(alpha = 0.5f),
    cursorColor = JColors.Cyan
)

@Composable
fun RoundButton(label: String, size: Dp, color: Color, fontSize: Int, onClick: () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.12f))
            .border(1.5.dp, color, CircleShape)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = color, fontSize = fontSize.sp)
    }
}

@Composable
fun Banner(text: String, accent: Color, onDismiss: (() -> Unit)?) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(accent.copy(alpha = 0.10f))
            .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = JColors.Text, fontSize = 13.sp, modifier = Modifier.weight(1f))
        if (onDismiss != null) {
            Text(
                "✕",
                color = JColors.Dim,
                fontSize = 16.sp,
                modifier = Modifier
                    .padding(start = 8.dp)
                    .clickable { onDismiss() }
            )
        }
    }
}

@Composable
fun ChatBubble(m: ChatMessage) {
    val mine = m.fromUser
    val accent = when {
        m.isError -> JColors.Red
        mine -> JColors.Blue
        else -> JColors.Cyan
    }
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start
    ) {
        Box(
            Modifier
                .widthIn(max = 300.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(accent.copy(alpha = 0.10f))
                .border(1.dp, accent.copy(alpha = 0.55f), RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(m.text, color = JColors.Text, fontSize = 15.sp)
        }
    }
}

@Composable
fun StatusRow(state: JarvisState, onStop: () -> Unit) {
    val battery by rememberBattery()
    val online by rememberOnline()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "J.A.R.V.I.S",
            color = JColors.Cyan,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 3.sp
        )
        Spacer(Modifier.weight(1f))
        if (state == JarvisState.LISTENING) {
            Text("● MIC ON", color = JColors.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.width(8.dp))
        }
        Text(
            if (battery >= 0) "🔋 $battery%" else "🔋 --",
            color = JColors.Text,
            fontSize = 12.sp
        )
        Spacer(Modifier.width(10.dp))
        Text(
            if (online) "● ONLINE" else "○ OFFLINE",
            color = if (online) JColors.Cyan else JColors.Red,
            fontSize = 12.sp
        )
        if (state != JarvisState.IDLE) {
            Spacer(Modifier.width(10.dp))
            Text(
                "STOP",
                color = JColors.Red,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, JColors.Red, RoundedCornerShape(8.dp))
                    .clickable { onStop() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}

@Composable
fun rememberBattery(): State<Int> {
    val ctx = LocalContext.current
    val level = remember { mutableStateOf(-1) }
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                level.value = if (l >= 0 && s > 0) l * 100 / s else -1
            }
        }
        val sticky = ContextCompat.registerReceiver(
            ctx,
            receiver,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        if (sticky != null) receiver.onReceive(ctx, sticky)
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    return level
}

@Composable
fun rememberOnline(): State<Boolean> {
    val ctx = LocalContext.current
    val online = remember { mutableStateOf(true) }
    DisposableEffect(Unit) {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        fun check(): Boolean {
            val n = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(n) ?: return false
            return caps.hasCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET)
        }
        online.value = check()
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                online.value = check()
            }

            override fun onLost(network: Network) {
                online.value = false
            }
        }
        cm.registerDefaultNetworkCallback(callback)
        onDispose { cm.unregisterNetworkCallback(callback) }
    }
    return online
}
