package com.jarvis.assistant

import android.app.Application
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val ctx = app.applicationContext
    private val store = SecureStore(ctx)

    val messages = mutableStateListOf<ChatMessage>()

    var state by mutableStateOf(JarvisState.IDLE)
        private set
    var partial by mutableStateOf("")
        private set
    var level by mutableFloatStateOf(0f)
        private set
    var notice by mutableStateOf<String?>(null)
        private set
    var hasKey by mutableStateOf(store.getSecret(KEY_NAME).isNotBlank())
        private set
    var language by mutableStateOf(store.getPref("lang", "hi-IN"))
        private set
    var continuous by mutableStateOf(store.getPref("continuous", "false") == "true")
        private set
    var model by mutableStateOf(store.getPref("model", GeminiClient.DEFAULT_MODEL))
        private set
    var hindiVoiceOk by mutableStateOf<Boolean?>(null)
        private set

    private var nextId = 0L
    private var job: Job? = null

    private val speaker = Speaker(ctx) { ok -> hindiVoiceOk = ok }

    private val stt = SpeechInput(ctx, object : SpeechInput.Callback {
        override fun onPartial(text: String) {
            if (state == JarvisState.LISTENING) partial = text
        }

        override fun onFinal(text: String) {
            if (state != JarvisState.LISTENING) return
            partial = ""
            level = 0f
            if (text.isBlank()) {
                state = JarvisState.IDLE
                notice = "कुछ सुनाई नहीं दिया। माइक दबाकर फिर बोलिए।"
            } else {
                submit(text.trim())
            }
        }

        override fun onError(code: Int) {
            if (state != JarvisState.LISTENING) return
            partial = ""
            level = 0f
            state = JarvisState.IDLE
            notice = when (code) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                    "कुछ सुनाई नहीं दिया। माइक दबाकर फिर बोलिए।"
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS ->
                    "माइक्रोफ़ोन की अनुमति नहीं मिली।"
                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                    "आवाज़ पहचानने के लिए इंटरनेट चाहिए (या Hindi ऑफ़लाइन पैक डाउनलोड करें)। कोड $code"
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY ->
                    "आवाज़ पहचान व्यस्त है, एक पल बाद फिर कोशिश करें।"
                else -> "आवाज़ पहचान में त्रुटि (कोड $code)।"
            }
        }

        override fun onLevel(rmsDb: Float) {
            if (state == JarvisState.LISTENING) level = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
        }
    })

    init {
        messages.add(ChatMessage(nextId++, false, greeting(), isGreeting = true))
    }

    private fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when {
            h < 12 -> "Good morning"
            h < 17 -> "Good afternoon"
            else -> "Good evening"
        }
        return "$g. JARVIS is online. बताइए, आज मैं आपकी क्या सहायता कर सकता हूँ?"
    }

    // ---------- Actions from the UI ----------

    /** Called when the mic is pressed (the UI has already checked the mic permission). */
    fun onMicPressed() {
        when (state) {
            JarvisState.IDLE -> startListening()
            JarvisState.LISTENING -> stt.stop()
            JarvisState.SPEAKING -> {
                speaker.stop()
                startListening()
            }
            JarvisState.THINKING -> {}
        }
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) {
            state = JarvisState.IDLE
            notice = "इस फ़ोन पर आवाज़ पहचानने की सेवा (Google) नहीं मिली।"
            return
        }
        speaker.stop()
        job?.cancel()
        partial = ""
        level = 0f
        notice = null
        state = JarvisState.LISTENING
        stt.start(language)
    }

    /** Emergency stop: stops the mic, the voice and any waiting AI request. */
    fun stopAll() {
        stt.cancel()
        speaker.stop()
        job?.cancel()
        job = null
        partial = ""
        level = 0f
        state = JarvisState.IDLE
    }

    fun sendTyped(text: String) {
        if (text.isBlank()) return
        stt.cancel()
        speaker.stop()
        job?.cancel()
        partial = ""
        level = 0f
        notice = null
        submit(text.trim())
    }

    fun clearHistory() {
        stopAll()
        messages.clear()
        messages.add(ChatMessage(nextId++, false, greeting(), isGreeting = true))
    }

    fun dismissNotice() {
        notice = null
    }

    fun showNotice(text: String) {
        notice = text
    }

    fun saveSettings(newKey: String, newModel: String, newLang: String, newContinuous: Boolean) {
        val cleanKey = newKey.filter { !it.isWhitespace() }
        if (cleanKey.isNotEmpty()) {
            if (store.putSecret(KEY_NAME, cleanKey)) {
                hasKey = true
                notice = "API key सुरक्षित रूप से सेव हो गई ✓"
            } else {
                notice = "API key सेव नहीं हो पाई। फिर कोशिश करें।"
            }
        }
        model = newModel.ifBlank { GeminiClient.DEFAULT_MODEL }
        language = newLang
        continuous = newContinuous
        store.putPref("model", model)
        store.putPref("lang", language)
        store.putPref("continuous", continuous.toString())
    }

    fun removeKey() {
        store.putSecret(KEY_NAME, "")
        hasKey = false
        notice = "API key हटा दी गई।"
    }

    fun testVoice() {
        stopAll()
        speakReply("नमस्ते, मैं जार्विस हूँ। मेरी आवाज़ ठीक से सुनाई दे रही है।")
    }

    // ---------- Internal logic ----------

    private fun submit(text: String) {
        messages.add(ChatMessage(nextId++, true, text))
        val key = store.getSecret(KEY_NAME)
        if (key.isBlank()) {
            messages.add(
                ChatMessage(
                    nextId++, false,
                    "पहले ⚙ सेटिंग्स में Gemini API key डालिए, फिर मैं जवाब दे पाऊँगा।",
                    isError = true
                )
            )
            state = JarvisState.IDLE
            return
        }
        state = JarvisState.THINKING

        val turns = messages
            .filter { !it.isError && !it.isGreeting }
            .takeLast(14)
            .map { GeminiClient.Turn(if (it.fromUser) "user" else "model", it.text) }
            .dropWhile { it.role == "model" }
        val currentModel = model

        job = viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                GeminiClient.ask(key, currentModel, turns, SYSTEM_PROMPT)
            }
            when (res) {
                is GeminiClient.Result.Ok -> {
                    messages.add(ChatMessage(nextId++, false, res.text))
                    speakReply(res.text)
                }
                is GeminiClient.Result.Err -> {
                    messages.add(ChatMessage(nextId++, false, res.message, isError = true))
                    state = JarvisState.IDLE
                }
            }
        }
    }

    private fun speakReply(text: String) {
        val ok = speaker.speak(text) { onSpeechDone() }
        if (ok) {
            state = JarvisState.SPEAKING
        } else {
            state = JarvisState.IDLE
            notice = "आवाज़ नहीं बोल पाई: फ़ोन में Hindi आवाज़ (Google Text-to-speech) उपलब्ध नहीं है। ⚙ सेटिंग्स देखें।"
        }
    }

    private fun onSpeechDone() {
        if (state != JarvisState.SPEAKING) return
        if (continuous && hasKey) startListening() else state = JarvisState.IDLE
    }

    override fun onCleared() {
        stt.destroy()
        speaker.shutdown()
        super.onCleared()
    }

    companion object {
        private const val KEY_NAME = "gemini_key"

        private const val SYSTEM_PROMPT =
            "You are J.A.R.V.I.S., a calm, intelligent and professional personal AI assistant " +
                "living on the user's Android phone, inspired by Iron Man's JARVIS. " +
                "The user speaks Hindi, English or Hinglish. " +
                "If the user speaks Hindi or Hinglish, reply in natural Hindi written in Devanagari script. " +
                "If the user speaks fully in English, reply in English. " +
                "Be respectful and address the user as 'आप'. " +
                "Keep answers short (one to three sentences) unless the user asks for detail. " +
                "Your replies are spoken aloud, so never use markdown, asterisks, bullet symbols, emojis or tables; " +
                "write plain sentences only. " +
                "Be honest: in this version you can only chat. You cannot yet open apps, set alarms, " +
                "control the phone, use the camera or remember things between sessions. " +
                "If asked to do those, say that this feature is coming in a later update. " +
                "Never claim that you did something you did not actually do."
    }
}
