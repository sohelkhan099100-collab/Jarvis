package com.jarvis.assistant

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores secrets (like the Gemini API key) encrypted with a key that lives
 * inside the Android Keystore, so the key never leaves the phone's secure hardware/area.
 * Normal settings are stored as plain preferences.
 */
class SecureStore(context: Context) {

    private val prefs = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    private fun getOrCreateKey(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore")
        ks.load(null)
        val existing = ks.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    /** Returns true if saved successfully. An empty value deletes the secret. */
    fun putSecret(name: String, value: String): Boolean {
        if (value.isEmpty()) {
            prefs.edit().remove("secret_$name").apply()
            return true
        }
        return try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val iv = cipher.iv
            val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            val packed = Base64.encodeToString(iv + encrypted, Base64.NO_WRAP)
            prefs.edit().putString("secret_$name", packed).apply()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun getSecret(name: String): String {
        val packed = prefs.getString("secret_$name", null) ?: return ""
        return try {
            val bytes = Base64.decode(packed, Base64.NO_WRAP)
            val iv = bytes.copyOfRange(0, 12)
            val data = bytes.copyOfRange(12, bytes.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(data), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }

    fun putPref(name: String, value: String) {
        prefs.edit().putString("pref_$name", value).apply()
    }

    fun getPref(name: String, default: String): String =
        prefs.getString("pref_$name", default) ?: default

    companion object {
        private const val ALIAS = "jarvis_master_key"
    }
}
