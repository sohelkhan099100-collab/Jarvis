package com.jarvis.assistant

enum class JarvisState { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatMessage(
    val id: Long,
    val fromUser: Boolean,
    val text: String,
    val isError: Boolean = false,
    val isGreeting: Boolean = false
)
