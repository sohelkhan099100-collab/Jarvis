package com.jarvis.assistant

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object JColors {
    val Black = Color(0xFF000000)
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF2979FF)
    val Panel = Color(0xFF05080F)
    val Text = Color(0xFFE6F7FF)
    val Dim = Color(0xFF7FA6B8)
    val Red = Color(0xFFFF3B5C)
}

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = JColors.Cyan,
            onPrimary = JColors.Black,
            secondary = JColors.Blue,
            background = JColors.Black,
            onBackground = JColors.Text,
            surface = JColors.Panel,
            onSurface = JColors.Text
        ),
        content = content
    )
}
