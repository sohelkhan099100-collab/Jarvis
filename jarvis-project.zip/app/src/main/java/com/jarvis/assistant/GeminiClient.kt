package com.jarvis.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Talks to Google's Gemini API (free tier via the user's own AI Studio key).
 * No extra libraries needed. Call from a background thread only.
 *
 * If one model is unavailable (404) or out of free quota (429/503),
 * the next model in the fallback list is tried automatically.
 */
object GeminiClient {

    const val DEFAULT_MODEL = "gemini-2.5-flash"
    private val FALLBACKS = listOf("gemini-2.5-flash-lite", "gemini-3.6-flash")

    data class Turn(val role: String, val text: String) // role = "user" or "model"

    sealed class Result {
        data class Ok(val text: String, val model: String) : Result()
        data class Err(val message: String) : Result()
    }

    private sealed class Attempt {
        data class Success(val text: String) : Attempt()
        data class Retry(val message: String) : Attempt()
        data class Fatal(val message: String) : Attempt()
    }

    fun ask(apiKey: String, preferredModel: String, turns: List<Turn>, systemPrompt: String): Result {
        val models = LinkedHashSet<String>()
        if (preferredModel.isNotBlank()) models.add(preferredModel)
        models.addAll(FALLBACKS)

        var lastError = "अज्ञात त्रुटि"
        for (m in models) {
            when (val r = callOnce(apiKey, m, turns, systemPrompt)) {
                is Attempt.Success -> return Result.Ok(r.text, m)
                is Attempt.Fatal -> return Result.Err(r.message)
                is Attempt.Retry -> lastError = r.message
            }
        }
        return Result.Err(lastError)
    }

    private fun callOnce(
        apiKey: String,
        model: String,
        turns: List<Turn>,
        systemPrompt: String
    ): Attempt {
        var conn: HttpURLConnection? = null
        try {
            val body = JSONObject()
            body.put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt)))
            )
            val contents = JSONArray()
            for (t in turns) {
                contents.put(
                    JSONObject()
                        .put("role", t.role)
                        .put("parts", JSONArray().put(JSONObject().put("text", t.text)))
                )
            }
            body.put("contents", contents)
            body.put(
                "generationConfig",
                JSONObject().put("temperature", 0.7).put("maxOutputTokens", 2048)
            )

            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = "POST"
            conn.connectTimeout = 15000
            conn.readTimeout = 60000
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setRequestProperty("x-goog-api-key", apiKey)
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

            if (code in 200..299) {
                return parseSuccess(text, model)
            }

            var apiMessage = ""
            try {
                apiMessage = JSONObject(text).optJSONObject("error")?.optString("message") ?: ""
            } catch (e: Exception) {
                // ignore: keep empty message
            }
            apiMessage = apiMessage.take(200)

            return when (code) {
                400 ->
                    if (apiMessage.contains("API key", ignoreCase = true))
                        Attempt.Fatal("API key सही नहीं है। ⚙ सेटिंग्स में दोबारा कॉपी-पेस्ट करें।")
                    else Attempt.Fatal("अनुरोध में समस्या (400): $apiMessage")
                401, 403 ->
                    Attempt.Fatal("API key काम नहीं कर रही या अनुमति नहीं है ($code)। $apiMessage")
                404 -> Attempt.Retry("मॉडल '$model' उपलब्ध नहीं है (404)।")
                429 -> Attempt.Retry("'$model' की फ़्री लिमिट अभी पूरी हो गई है (429)। थोड़ी देर बाद कोशिश करें।")
                500, 502, 503, 504 -> Attempt.Retry("Google का सर्वर अभी व्यस्त है ($code)। थोड़ी देर बाद कोशिश करें।")
                else -> Attempt.Fatal("त्रुटि ($code): $apiMessage")
            }
        } catch (e: IOException) {
            return Attempt.Fatal("इंटरनेट कनेक्शन की समस्या: ${e.message ?: "अज्ञात"}")
        } catch (e: Exception) {
            return Attempt.Fatal("अप्रत्याशित त्रुटि: ${e.message ?: e.javaClass.simpleName}")
        } finally {
            conn?.disconnect()
        }
    }

    private fun parseSuccess(text: String, model: String): Attempt {
        val root = JSONObject(text)
        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val reason = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return Attempt.Fatal(
                if (reason.isNotEmpty()) "Google ने यह अनुरोध रोक दिया ($reason)।"
                else "कोई जवाब नहीं मिला।"
            )
        }
        val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val p = parts.getJSONObject(i)
                if (p.optBoolean("thought", false)) continue
                sb.append(p.optString("text", ""))
            }
        }
        val out = sb.toString().trim()
        return if (out.isEmpty()) Attempt.Retry("'$model' से खाली जवाब मिला।") else Attempt.Success(out)
    }
}
