package com.jarvis.assistant

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/**
 * Wraps Android's built-in TextToSpeech. Picks a Hindi voice for Devanagari text
 * and an English voice otherwise. Main thread only.
 */
class Speaker(context: Context, private val onInit: (hindiAvailable: Boolean) -> Unit) {

    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var token = 0

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    ready = true
                    onInit(isAvailable("hi-IN"))
                } else {
                    onInit(false)
                }
            }
        }
    }

    private fun isAvailable(tag: String): Boolean {
        val engine = tts ?: return false
        val r = engine.isLanguageAvailable(Locale.forLanguageTag(tag))
        return r >= TextToSpeech.LANG_AVAILABLE
    }

    /**
     * Speaks the text. Returns false if no suitable voice is available
     * (in that case nothing is spoken and whenDone is not called).
     */
    fun speak(raw: String, whenDone: () -> Unit): Boolean {
        val engine = tts ?: return false
        if (!ready) return false
        val clean = clean(raw)
        if (clean.isBlank()) return false

        val devanagari = clean.count { it in 'ऀ'..'ॿ' }
        val hindi = devanagari * 4 > clean.length
        val candidates = if (hindi) listOf("hi-IN") else listOf("en-IN", "en-US", "en-GB")
        val tag = candidates.firstOrNull { isAvailable(it) } ?: return false
        engine.setLanguage(Locale.forLanguageTag(tag))

        token++
        val myToken = token
        val chunks = chunk(clean)
        val lastId = "j_${myToken}_${chunks.size - 1}"

        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) {
                if (utteranceId == lastId) finish(myToken, whenDone)
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                finish(myToken, whenDone)
            }
        })

        chunks.forEachIndexed { i, c ->
            engine.speak(
                c,
                if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
                null,
                "j_${myToken}_$i"
            )
        }
        return true
    }

    private fun finish(t: Int, cb: () -> Unit) {
        main.post { if (t == token) cb() }
    }

    /** Interrupt speech immediately. The onDone callback of the old speech will not fire. */
    fun stop() {
        token++
        tts?.stop()
    }

    fun shutdown() {
        token++
        tts?.stop()
        tts?.shutdown()
        tts = null
    }

    private fun clean(s: String): String =
        s.replace(Regex("[*_`#>~|]"), "")
            .replace(Regex("\\s*\\n+\\s*"), ". ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun chunk(text: String): List<String> {
        val out = mutableListOf<String>()
        val sb = StringBuilder()
        for (sentence in text.split(Regex("(?<=[।.!?])\\s+"))) {
            if (sb.isNotEmpty() && sb.length + sentence.length > 450) {
                out.add(sb.toString().trim())
                sb.clear()
            }
            sb.append(sentence).append(' ')
        }
        if (sb.isNotBlank()) out.add(sb.toString().trim())
        return out.flatMap { if (it.length > 3500) it.chunked(3500) else listOf(it) }
    }
}
