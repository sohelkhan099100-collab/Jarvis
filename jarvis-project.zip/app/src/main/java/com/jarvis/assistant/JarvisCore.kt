package com.jarvis.assistant

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** The big animated circular AI core in the middle of the screen. */
@Composable
fun JarvisCore(state: JarvisState, level: Float, modifier: Modifier = Modifier) {
    val speed by rememberUpdatedState(
        when (state) {
            JarvisState.IDLE -> 14f
            JarvisState.LISTENING -> 40f
            JarvisState.THINKING -> 150f
            JarvisState.SPEAKING -> 70f
        }
    )
    val st by rememberUpdatedState(state)
    val lvl by animateFloatAsState(targetValue = level, animationSpec = tween(100), label = "level")
    var angle by remember { mutableFloatStateOf(0f) }
    var clock by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanosCompat()
        while (true) {
            val now = withFrameNanosCompat()
            val dt = (now - last) / 1_000_000_000f
            last = now
            angle = (angle + dt * speed) % 360f
            clock += dt
        }
    }

    Canvas(modifier) {
        val c = center
        val m = size.minDimension

        val pulse = when (st) {
            JarvisState.IDLE -> sin(clock * 1.6f) * 0.012f
            JarvisState.LISTENING -> lvl * 0.10f + sin(clock * 3f) * 0.01f
            JarvisState.THINKING -> sin(clock * 6f) * 0.025f
            JarvisState.SPEAKING -> (sin(clock * 10f) * 0.5f + 0.5f) * 0.07f
        }
        val orb = m * (0.17f + pulse)

        // soft glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    JColors.Cyan.copy(alpha = 0.50f),
                    JColors.Blue.copy(alpha = 0.22f),
                    Color.Transparent
                ),
                center = c,
                radius = orb * 3.2f
            ),
            radius = orb * 3.2f,
            center = c
        )

        // central orb
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.95f), JColors.Cyan, JColors.Blue),
                center = c,
                radius = orb
            ),
            radius = orb,
            center = c
        )

        // thin static ring
        drawCircle(
            color = JColors.Cyan.copy(alpha = 0.35f),
            radius = m * 0.27f,
            center = c,
            style = Stroke(width = 1.5.dp.toPx())
        )

        // two bright rotating arcs
        val r1 = m * 0.31f
        rotate(degrees = angle, pivot = c) {
            drawArc(
                color = JColors.Cyan,
                startAngle = 0f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(c.x - r1, c.y - r1),
                size = Size(r1 * 2, r1 * 2),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
            drawArc(
                color = JColors.Cyan,
                startAngle = 180f,
                sweepAngle = 100f,
                useCenter = false,
                topLeft = Offset(c.x - r1, c.y - r1),
                size = Size(r1 * 2, r1 * 2),
                style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
            )
        }

        // dashed ring rotating the other way
        rotate(degrees = -angle * 1.6f, pivot = c) {
            drawCircle(
                color = JColors.Blue.copy(alpha = 0.85f),
                radius = m * 0.385f,
                center = c,
                style = Stroke(
                    width = 2.dp.toPx(),
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 18f))
                )
            )
        }

        // outer tick marks
        rotate(degrees = angle * 0.6f, pivot = c) {
            val outer = m * 0.47f
            for (i in 0 until 60) {
                val a = Math.toRadians(i * 6.0)
                val len = if (i % 5 == 0) 12.dp.toPx() else 6.dp.toPx()
                val x1 = c.x + outer * cos(a).toFloat()
                val y1 = c.y + outer * sin(a).toFloat()
                val x2 = c.x + (outer - len) * cos(a).toFloat()
                val y2 = c.y + (outer - len) * sin(a).toFloat()
                drawLine(
                    color = JColors.Cyan.copy(alpha = if (i % 5 == 0) 0.9f else 0.4f),
                    start = Offset(x1, y1),
                    end = Offset(x2, y2),
                    strokeWidth = 1.5.dp.toPx()
                )
            }
        }
    }
}

private suspend fun withFrameNanosCompat(): Long =
    androidx.compose.runtime.withFrameNanos { it }

/** Row of vertical bars that move with the voice level. */
@Composable
fun Waveform(state: JarvisState, level: Float, modifier: Modifier = Modifier) {
    val st by rememberUpdatedState(state)
    val lvl by animateFloatAsState(targetValue = level, animationSpec = tween(100), label = "wave")
    var t by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(Unit) {
        var last = withFrameNanosCompat()
        while (true) {
            val now = withFrameNanosCompat()
            t += (now - last) / 1_000_000_000f
            last = now
        }
    }

    Canvas(modifier) {
        val bars = 40
        val slot = size.width / bars
        val cy = size.height / 2f
        val amp = when (st) {
            JarvisState.LISTENING -> 0.15f + lvl * 0.85f
            JarvisState.SPEAKING -> 0.55f
            JarvisState.THINKING -> 0.18f
            JarvisState.IDLE -> 0.04f
        }
        for (i in 0 until bars) {
            val x = slot * (i + 0.5f)
            val envelope = 1f - abs(i - bars / 2f) / (bars / 2f)
            val wave = sin(t * 7f + i * 0.55f) * 0.5f + 0.5f
            val h = size.height * (0.05f + amp * envelope * wave)
            drawLine(
                color = JColors.Cyan.copy(alpha = 0.35f + 0.65f * envelope),
                start = Offset(x, cy - h / 2f),
                end = Offset(x, cy + h / 2f),
                strokeWidth = slot * 0.45f,
                cap = StrokeCap.Round
            )
        }
    }
}
