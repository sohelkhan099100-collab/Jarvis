package com.jarvis.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SettingsDialog(vm: MainViewModel, onDismiss: () -> Unit) {
    var key by remember { mutableStateOf("") }
    var model by remember { mutableStateOf(vm.model) }
    var lang by remember { mutableStateOf(vm.language) }
    var cont by remember { mutableStateOf(vm.continuous) }
    val uriHandler = LocalUriHandler.current

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = JColors.Panel,
        title = { Text("सेटिंग्स", color = JColors.Cyan) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Gemini API key", color = JColors.Text, fontSize = 14.sp)
                Text(
                    if (vm.hasKey) "✓ key सेव है (नई डालने पर बदल जाएगी)" else "अभी कोई key नहीं है",
                    color = if (vm.hasKey) JColors.Cyan else JColors.Red,
                    fontSize = 12.sp
                )
                Spacer(Modifier.height(6.dp))
                OutlinedTextField(
                    value = key,
                    onValueChange = { key = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("यहाँ key पेस्ट करें", color = JColors.Dim) },
                    visualTransformation = PasswordVisualTransformation(),
                    colors = fieldColors()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/apikey") }) {
                        Text("key बनाने का पेज खोलें", color = JColors.Blue, fontSize = 12.sp)
                    }
                    if (vm.hasKey) {
                        TextButton(onClick = { vm.removeKey() }) {
                            Text("key हटाएँ", color = JColors.Red, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))
                Text("AI मॉडल का नाम", color = JColors.Text, fontSize = 14.sp)
                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    colors = fieldColors()
                )

                Spacer(Modifier.height(10.dp))
                Text("बोलने की भाषा (पहचान)", color = JColors.Text, fontSize = 14.sp)
                LangRow("हिंदी (hi-IN)", lang == "hi-IN") { lang = "hi-IN" }
                LangRow("English (en-IN)", lang == "en-IN") { lang = "en-IN" }

                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("लगातार बातचीत", color = JColors.Text, fontSize = 14.sp)
                        Text(
                            "जवाब के बाद माइक अपने आप फिर चालू होगा (स्क्रीन पर MIC ON दिखेगा)",
                            color = JColors.Dim,
                            fontSize = 11.sp
                        )
                    }
                    Switch(checked = cont, onCheckedChange = { cont = it })
                }

                Spacer(Modifier.height(10.dp))
                Text("आवाज़ की जाँच", color = JColors.Text, fontSize = 14.sp)
                Text(
                    when (vm.hindiVoiceOk) {
                        true -> "Hindi आवाज़: उपलब्ध ✓"
                        false -> "Hindi आवाज़: उपलब्ध नहीं ✗"
                        null -> "आवाज़ इंजन चालू हो रहा है…"
                    },
                    color = if (vm.hindiVoiceOk == false) JColors.Red else JColors.Cyan,
                    fontSize = 12.sp
                )
                TextButton(onClick = { vm.testVoice(); onDismiss() }) {
                    Text("आवाज़ टेस्ट करें", color = JColors.Blue)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                vm.saveSettings(key.trim(), model.trim(), lang, cont)
                onDismiss()
            }) { Text("सेव करें", color = JColors.Cyan) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("रद्द करें", color = JColors.Dim) }
        }
    )
}

@Composable
private fun LangRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, color = JColors.Text, fontSize = 14.sp)
    }
}
